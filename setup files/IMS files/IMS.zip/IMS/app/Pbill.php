<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pbill extends Model
{
    //
}

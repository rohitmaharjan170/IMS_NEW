<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ppayment extends Model
{
    //
}
